<?php 
setcookie('user','',0,'/');
header("Location: ?r=login");
?>