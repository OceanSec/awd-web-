<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy">&copy; 2015 | <a href="http://www.isea.pw" target="_blank">熊海CMS V1.0</a> & 保留所有权利  </p>
      </div>
    </div>
  </div>
</footer> 