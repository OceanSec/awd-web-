

SET time_zone = "+00:00";

create database software_project_manage;

use software_project_manage;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `username` varchar(20) UNIQUE,
  `password` varchar(50) NOT NULL,
  `data` datetime NOT NULL,
  `description` text NOT NULL
);
insert into admin(username, password, description) value ('admin111','admin111','Main Admin , check脚本检测需要用此用户，不要改密');

create table `users`(
	`id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`username` varchar(20) NOT NULL unique,
	`SID` varchar(20) NOT NULL,
	`password` varchar(50) NOT NULL,
	`tel` varchar(20) NOT NULL,
	`register_data` datetime NOT NULL,
	`project_name` varchar(20),
	`data` varchar(50) NOT NULL,
	`grade` int
);

insert into `users` (`username`,`SID`,`password`,`tel`,`Project_name`,`grade`) value ('解宇飞','1707004101','test111','123456','工控安全',0);-- testing!!
insert into `users` (`username`,`SID`,`password`,`tel`,`Project_name`,`grade`) value ('徐开新','1707004102','test111','234456','云安全',0);
insert into `users` (`username`,`SID`,`password`,`tel`,`Project_name`,`grade`) value('丁晓凡','1707004103','test111','789','WEB安全',0);

create table `projects`(
	`id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`projectname` varchar(40) NOT NULL,
	`teacher` varchar(20) NOT NULL,
	`description` text NOT NULL,
	`student_number` int(10) NOT NULL
);

insert into `projects` values('','工控安全','乔道济','该题目提供计组',1);
insert into `projects` values('','云安全','刘永超','该题目仅提供4班同学',1);
insert into `projects` values('','WEB安全','梁志剑','欢迎大二同学！',1);
insert into `projects` values('','软件二进制安全','韩慧研','会数学的来',0);


